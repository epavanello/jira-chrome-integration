(function () {
	'use strict';

	const importPath = /*@__PURE__*/JSON.parse('"../content/content_script.js"');

	import(chrome.runtime.getURL(importPath));

}());
