import { M, B, a, f as f$1, i, l, h, u, c, d, p, t, s, o } from '../index-2b855a54.js';

function b(t$1){let e,s$1,b,g,f,m,k,w,y,h$1;return {c(){e=f$1("main"),s$1=f$1("p"),b=i(t$1[0]),g=l(),f=f$1("div"),m=f$1("button"),m.textContent="-",k=l(),w=f$1("button"),w.textContent="+",h(s$1,"data-testid","counter-value"),h(s$1,"class","text-xl text-center"),h(m,"class","px-4 py-1 bg-red-500"),h(w,"class","px-4 py-1 bg-green-500"),h(f,"class","flex text-xl text-white");},m(a,n){u(a,e,n),c(e,s$1),c(s$1,b),c(e,g),c(e,f),c(f,m),c(f,k),c(f,w),y||(h$1=[d(m,"click",t$1[2]),d(w,"click",t$1[1])],y=!0);},p(t,[e]){1&e&&p(b,t[0]);},i:t,o:t,d(t){t&&s(e),y=!1,o(h$1);}}}function g(t,e,s){let a=0;return [a,()=>s(0,a+=1),()=>s(0,a-=1)]}console.log("content script working");const f=new class extends M{constructor(t){super(),B(this,t,g,b,a,{});}}({target:document.body});

export default f;
